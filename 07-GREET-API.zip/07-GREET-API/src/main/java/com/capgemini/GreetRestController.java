package com.capgemini;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetRestController {
	
	@GetMapping("/welcome")
	public String greetMessage()
	{
		
		String msg="Good Morning";
		
		return msg;
		
		
	}

}
